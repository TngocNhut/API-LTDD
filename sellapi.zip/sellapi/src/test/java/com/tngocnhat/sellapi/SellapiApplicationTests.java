package com.tngocnhat.sellapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SellapiApplicationTests {

	@Test
	void contextLoads() {
	}

}
