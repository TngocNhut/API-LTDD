package com.tngocnhat.sellapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SellapiApplication {

	public static void main(String[] args) {
		SpringApplication.run(SellapiApplication.class, args);
	}

}
